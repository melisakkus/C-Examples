/* */
#include <stdio.h>
int main(){
    int alt_sinir,ust_sinir,toplam=0;
    
    printf("alt sınır değeri: ");
    scanf("%d",&alt_sinir);
    
    printf("üst sınır değeri: ");
    scanf("%d",&ust_sinir);
    
    for(int i=alt_sinir;i<=ust_sinir;i++){
        toplam += i ;
    }
    
    printf("aralıktaki sayıların toplamı : %d",toplam);
}