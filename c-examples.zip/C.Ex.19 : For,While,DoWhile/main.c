/* while 2 : 1'den başlayarak kullanıcıdan 
    alınan sayıya kadar sayıları yazdır 
    for, while, do while*/

#include <stdio.h>
int main(){
    int sayi,i;
    printf("sayi: ");
    scanf("%d",&sayi);
    
    for(i=1;i<=sayi;i++){
        printf("%d ",i);
    }
    
    printf("\n");
    i=1;
    while(i<=sayi){
        printf("%d ",i);
        i++;
    }
    
    printf("\n");
    
    i=1;
    do{
        printf("%d ",i);
        i++;}
        while(i<=sayi); // bu işlemleri yap i<=n olduğu sürece
    
}

/* for : kaç defa tekrar edileceği belli olduğunda 
 while : koşul sağlanmıyorsa döngü içine hiç girmez
 do - while önce işlemi yapar koşul sağlanıyorsa tekrar döngüye girer