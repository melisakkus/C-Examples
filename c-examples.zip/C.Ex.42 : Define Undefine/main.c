// define ve undefine makroları
#include <stdio.h>

#define buyuk_sayı 1000 // = veya ; kullanmıyoruz

int fonksiyon(int sayi){
    return (sayi<buyuk_sayı);
/* return (sayi<diger_buyuk_sayı); error: ‘diger_buyuk_sayı’ undeclared 
(first use in this function); did you mean ‘buyuk_sayı’?
    
define her yerde geçerlidir ama constant tanımlı olduğu fonksiyon içerisinde
geçerlidir. */

}

int main(){
    int ilk_degisken=20;
    int ikinci_degisken=25;
    int sonuc1,sonuc2;
    const int diger_buyuk_sayı= 1000;
    
    printf("Büyük Sayi:%d",buyuk_sayı);
    
    sonuc1=ilk_degisken<buyuk_sayı;
    printf("\nSonuç1:%d",sonuc1);
    
    sonuc2=ikinci_degisken<buyuk_sayı;
    printf("\nSonuç2:%d",sonuc2);
    
    #undef buyuk_sayı
    #define buyuk_sayı 2000
    printf("\nBüyük Sayi:%d",buyuk_sayı);

}
    
