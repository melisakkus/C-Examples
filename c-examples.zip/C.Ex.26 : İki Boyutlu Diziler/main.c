/* çok boyutlu dizi yazdımra */

#include <stdio.h>
int main(){
    int matris[3][2]={{3,5},{1,2},{3,7}};
    int satir,sütun;
    for(satir=0;satir<3;satir++){
        for(sütun=0;sütun<2;sütun++){
            printf("%d ",matris[satir][sütun]);
        }
        printf("\n");
    }
}