// armstrong sayı
#include <stdio.h>
#include <math.h>

int ArmstrongMu(int sayi);

int main(){
    int sayi;
    printf("sayiyi giriniz: ");
    scanf("%d",&sayi);
    
    if(ArmstrongMu(sayi)){
        printf("%d sayi armstrongdur.",sayi);
    }
    else{
        printf("%d sayi armstrong değildir.",sayi);
    }
}

// abc sayısında (n basamak sayısı) a^n+b^n+c^n=abc ise sayı armstrongudr 
int ArmstrongMu(int sayi){
    int sonbasamak,basamaksayisi,toplam,orijinalsayi;
    toplam=0;
    orijinalsayi=sayi;

/* Birden büyük bir tam sayının kaç basamaklı olduğunu bulmak için 
sayının 10 tabanında logaritması alınır, sonucun ondalık kısmı atılır 
ve tam sayı kısmına 1 eklenir. */

    basamaksayisi=(int) log10(sayi) + 1;
    
    while(sayi>0){
        sonbasamak=sayi % 10; //son basamağı al
        toplam = toplam + round(pow(sonbasamak,basamaksayisi)); // son basamağın üstelini al ve toplama ekle
        sayi=sayi/10; //sayinin son basamağını yok et;
    }
    
    return (orijinalsayi == toplam);
    
}
