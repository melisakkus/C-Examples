// konum berliteci : register
//indeks değerleri sık kullanılıyorsa regstere kaydetmek daha hızlı ulaşım sağlar
#include <stdio.h>
int main(){
    
    register int i;
    
    int yeniDizi[5]={1,2,3,4,5};
    
    for(i=0;i<5;i++){
        printf("yeniDizi[%d]:%d\n",i,yeniDizi[i]);
    }
}