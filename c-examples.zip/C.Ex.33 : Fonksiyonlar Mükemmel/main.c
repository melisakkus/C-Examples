/* sayı mükemmel mi? Mükemmel sayı, sayılar teorisinde, 
kendisi hariç pozitif tam bölenlerinin toplamı kendisine eşit olan sayı. 
6 bölenleri 1+2+3=6 mükemmel sayıdır */

#include <stdio.h>

int MukemmelMi(int sayi);

int main(){
    int sayi;
    printf("sayıyı giriniz: ");
    scanf("%d",&sayi);
    if(MukemmelMi(sayi)){
        printf("%d sayısı mükemmeldir",sayi);
    }
    else{
        printf("%d sayısı mükemmel değildir",sayi);
    }
}

int MukemmelMi(int sayi){
    int i,toplam;
    toplam = 0;
    
    for(i=1;i<sayi;i++){
        if(sayi%i==0){
            toplam=toplam+i;
        }
    }
    
    return (sayi==toplam);
    
}
