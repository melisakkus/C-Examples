/* çarpım tablosu oluşturma */

#include <stdio.h>
int main(){
    int sayi,carpim;
    printf("sayiyi giriniz: ");
    scanf("%d",&sayi);
    
    for(int i=1;i<=sayi;i++){
        for(int j=1;j<=sayi; j++){
            carpim=i*j;
            printf(" %d ",carpim);
        }
        printf("\n");
    }
}