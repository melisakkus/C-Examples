#include <stdio.h>
int main(){
    /* maliyet ve satıl bilgisiyle kar-zarar belirleme */ 
    
    int maliyet,satis_bedeli,kar_zarar;
    
    printf("ürünün maliyeti: ");
    scanf("%d",&maliyet);
    printf("ürünün satış bedeli:  ");
    scanf("%d",&satis_bedeli);
    
    if(satis_bedeli>maliyet){
        kar_zarar=satis_bedeli-maliyet;
        printf("%d tl kar elde edilmiştir",kar_zarar);
    }
    else if(satis_bedeli<maliyet){
        kar_zarar=maliyet-satis_bedeli;
        printf("%d tl zarar elde edilmiştir",kar_zarar);
    }
    else {
        printf("kar veya zarar elde edilmemeiştir");
    }
}