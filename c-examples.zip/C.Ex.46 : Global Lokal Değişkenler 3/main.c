// globaal lokal değişkenler; fonksiyon parametreleri
#include <stdio.h>
int a=20; //global değişken deklarasyonu

int toplamaFonksiyonu(int a,int b){
    printf("\na'nın fonksiyona giriş değeri:%d",a);
    printf("\nb'nin fonksiyona giriş değeri:%d",b);
    
    a *= 12;
    b += 5;
    
    printf("\na'nın fonksiyondan çıkış değeri:%d",a);
    printf("\nb'nin fonksiyondan çıkış değeri:%d",b);

    return a+b;
}

int main(){
    int a= 10;
    int b= 20;
    int c= 0;
    
    printf("\na'nın main giriş değeri:%d",a);
    printf("\nb'nin main giriş değeri:%d",b);
    
    c=toplamaFonksiyonu(a,b);
    printf("\nc'nın main içindeki değeri:%d",c);
    printf("\na'nın main içindeki değeri:%d",a);
    printf("\nb'nin main içindeki değeri:%d",b);

}