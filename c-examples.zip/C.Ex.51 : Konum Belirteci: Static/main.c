//konum belirteci : static farklı fonksiyonlarda bile değişkenin değerini korur

#include <stdio.h>

void degerArtir(int k){
    static int sayi=0;
    printf("sayi:%d \n",sayi);
    sayi += k;
}

int main(){
    degerArtir(3);
    degerArtir(3);
    degerArtir(3);
    degerArtir(3);
}