#include <stdio.h>

int TekCift(int sayi);

int main(){
    int sayi;
    char sonuc;
    printf("sayiyi giriniz: ");
    scanf("%d",&sayi);
    sonuc=TekCift(sayi); // int main içerisinde fonksiyonun sonucunu
                        // döndürmemiz lazım !
}

int TekCift(int sayi){
    if (sayi % 2 == 0){
        return printf("%d sayisi çifttir",sayi);
    }
    else{
        printf("%d sayisi tektir",sayi);
    }
}
    