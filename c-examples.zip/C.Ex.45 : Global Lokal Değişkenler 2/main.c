/* global ve lokal değişken aynı ismi alabilir mi?
alabilir ama lokal olanın dediği olur */

#include <stdio.h>

int g=50; //global değişken beyanı
int main(){
    printf("global değer:%d",g);
    int a,b,g;
    a=10;
    b=20;
    g=a+b; //lokal değişken beyanı
    printf("\nlokal değeri:%d",g);
    //main içerisinde lokale atanan değer önemli !
}