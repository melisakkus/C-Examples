// sayı asal mı?
#include <stdio.h>

int AsalMi(int sayi){
    for(int i=2;i<sayi;i++){
        if(sayi % i == 0){
            return 0;
        }
    }
    return 1;
}

int main(){
    int sayi;
    printf("sayıyı giriniz: ");
    scanf("%d",&sayi);
    if(AsalMi(sayi)){
        printf("sayı asaldır");
    }
    else{
        printf("asal değildir");
    }
}
