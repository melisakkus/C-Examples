// bir sayının küpünü hesaplama
#include <stdio.h>

int küpHesabi(int sayi){
    return sayi*sayi*sayi;
}

int main(){
    int sayi,küp;
    printf("sayıyı giriniz: ");
    scanf("%d",&sayi);
    küp=küpHesabi(sayi);
    printf("%d sayısının küpü %d'dir.",sayi,küp);
}