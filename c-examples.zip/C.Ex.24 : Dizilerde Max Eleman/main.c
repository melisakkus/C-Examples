/* dizide en büyük eleman bulma */

#include <stdio.h>
int main(){
    int örnekDizi[]={3,4,7,1,2,1,9,0};
    int indeks;
    int enBüyükDeğer=örnekDizi[0];
    int konum = 0;
    int boyut;
    
    boyut= sizeof(örnekDizi) / sizeof(örnekDizi[0]);
    
    for(indeks=0;indeks<boyut;indeks++){
        if(örnekDizi[indeks]>enBüyükDeğer){
            enBüyükDeğer=örnekDizi[indeks];
            konum=indeks;
        }
    }
    printf("dizinin boyutu %d , en büyük değeri : %d ve konumu: %d",boyut,enBüyükDeğer,konum);
}
