/* özyinelemeli recursive fonksiyonlar - faktöriyel hesabı */
#include <stdio.h>

int faktöriyelHesabı(int sayi){
    if(sayi>1){
        return sayi*faktöriyelHesabı(sayi-1);}
    else{
        return 1;
    }
}

int main(){
    int sayi,sonuc;
    printf("sayiyi giriniz: ");
    scanf("%d",&sayi);
    sonuc=faktöriyelHesabı(sayi);
    printf("\n sayının faktöriyeli %d dir",sonuc);
}