//realloc örneği 
#include <stdio.h>
#include <stdlib.h>
int main(){
    int i,boyut,*isaretci,yeniboyut;
    printf("boyutu giriniz: ");
    scanf("%d",&boyut);
    
    isaretci = (int*) malloc(boyut*sizeof(int));
    printf("ayrılan mevcut belleklerin adresi: ");
    for(i=0;i<boyut;i++){
        printf("%pc\n",isaretci +i);
    }
    
    printf("yeni boyutu giriniz: ");
    scanf("%d",&yeniboyut);
    isaretci= realloc(isaretci,yeniboyut*sizeof(int));
    
    printf("ayrılan yeni belleklerin adresi: ");
    for(i=0;i<yeniboyut;i++){
        printf("%pc\n",isaretci+i);}
    
    free(isaretci);

}