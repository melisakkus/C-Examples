//konum belirteci : auto 

#include <stdio.h>

void degerArtir(int k){
    auto int sayi = 0;
    printf("sayi:%d \n",sayi);
    sayi += k;
}
int main(){
    degerArtir(5);
    degerArtir(5);
    degerArtir(5);
    degerArtir(5);
}