/* özyinelemeli recursive fonksiyonlar - fibanocci hesabı */
#include <stdio.h>

int fibanocciHesabı(int sayi){
    if(sayi==1){
        return 0;}
    else if(sayi==2){
        return 1;}
    else{
        return fibanocciHesabı(sayi-1)+fibanocciHesabı(sayi-2);
    }
}

int main(){
    int sayi,sonuc;
    printf("sayiyi giriniz: ");
    scanf("%d",&sayi);
    sonuc=fibanocciHesabı(sayi);
    for(int i=1;i<=sayi;i++){
        printf("%d ",fibanocciHesabı(i));
    }
}
