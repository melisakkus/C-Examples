/* dizi içine eleman ekleme */

#include <stdio.h>
int main(){
    int benimDizim[]={3,6,7,1,2,3,4};
    int indeks;
    int boyut;
    int yeniEleman;
    int yeniElemanİndeksi;
    
    boyut= sizeof(benimDizim) / sizeof(benimDizim[0]);
    
    printf("yeni elemanı giriniz: ");
    scanf("%d",&yeniEleman);
    printf("yeni elemanın indeksini giriniz: ");
    scanf("%d",&yeniElemanİndeksi);
    
    printf("şuanki dizi: ");

    for(indeks=0;indeks<boyut;indeks++){
        printf("%d ",benimDizim[indeks]);

    }
    
    for(indeks=boyut-1;indeks>yeniElemanİndeksi;indeks--){
        benimDizim[indeks]=benimDizim[indeks-1];
        }
    
    benimDizim[yeniElemanİndeksi]=yeniEleman;
    
    printf("\n yeni dizi: ");

    for(indeks=0;indeks<boyut;indeks++){
        printf("%d ",benimDizim[indeks]);

    }

}
