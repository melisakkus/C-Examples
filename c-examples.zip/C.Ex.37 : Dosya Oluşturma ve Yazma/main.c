// dosya oluşturma ve yazma
#include <stdio.h>
#include <stdlib.h>
#define VERİ_BOYUTU 1000 // 1000 karakterlik bir yer açıyoruz

int main(){
    char veri[VERİ_BOYUTU]; // veri boyutunu depolayan karakter dizisini tanımladık
    FILE * fPtr; // file pointer to hold referance to our file 
    
    fPtr=fopen("dosya1.txt","w+"); // dosyayı w (write) modunda aç, "data/file1.txt" dosyanın güzergahı
    
    if(fPtr==NULL){  // fopen() eğer başarısız olursa NULL döner
        printf("Dosya oluşturulamadı.\n");
        exit(EXIT_FAILURE); // dosya oluşturulamadığı için programdan (mainden) çık
    }
    
    printf("Dosyaya yazdırılacak metin: ");
    fgets(veri,VERİ_BOYUTU,stdin); //metni veri değişkeninin içine attık,
                                    //boyutu VERİ_BOYUTU kadar,standart input olarak tanımladık
    fputs(veri,fPtr);//alınan veriyi dosyaya yaz
    fclose(fPtr); //dosyayı kapat
    printf("dosya başarıyla yazdırıldı");
}
    
    
    