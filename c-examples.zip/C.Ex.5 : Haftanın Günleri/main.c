/* haftanın günlerini isim ile yazdırma */

#include<stdio.h>
int main(){
    int gun;
    printf("haftanın kaçıncı günü : ");
    scanf("%d",&gun);
    
    if(gun==1){
        printf("pazartesi");
    }
    else if(gun==2){
        printf("salı");
    }
    else if(gun==3){
        printf("çarşamba");
    }
    else if(gun==4){
        printf("perşembe");
    }
    else if(gun==5){
        printf("cuma");
    }
    else if(gun==6){
        printf("cumartesi");
    }
    else {
        printf("pazar");
    }
}