/* ikinci derece denklemin köklerini bulma */

#include <stdio.h>
#include <math.h>
int main(){
    int a,b,c;
    float diskriminant,kok1,kok2;
    printf("denklemin katsayılarını giriniz a: ");
    scanf("%d",&a);
    printf("denklemin katsayılarını giriniz b: ");
    scanf("%d",&b);
    printf("denklemin katsayılarını giriniz c: ");
    scanf("%d",&c);
    
    diskriminant=sqrt(b*b-4*a*c);
    
    if(diskriminant>0){
            kok1=(-b+diskriminant)/(2*a);
            kok2=(-b-diskriminant)/(2*a);
    
            printf("denklemin köklerininin 1.si: %f",kok1);
            printf("denklemin köklerininin 2.si: %f",kok2);
    }
    else if(diskriminant==0){
        kok1= kok2 = (-b+diskriminant)/(2*a);
        printf("denklemin kökleri eşittir: %f ve %f",kok1,kok2);

    }
    else{
        printf("denklemin reel kökü yoktur");
    }



}