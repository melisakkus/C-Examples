/* sayının çarpanlarını yazdırma */
#include <stdio.h>
int main(){
    int sayi,i;
    printf("sayiyi giriniz: ");
    scanf("%d",&sayi);
    
    
    printf("sayının çarpanları: ");
    for(i=1;i<=sayi;i++){
        if(sayi%i == 0){
            printf(" %d ",i);
        }
    }
}