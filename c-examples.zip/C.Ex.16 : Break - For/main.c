/* break komutu; koşul sağlandığında for döngüsünden çıkar */

#include <stdio.h>
int main(){
    int sayi,i;
    printf("sayi: ");
    scanf("%d",&sayi);
    
    for(i=1;i<=sayi;i++){
        if(i == 4){
            break;
        }
        printf(" %d ",i);
    }
}