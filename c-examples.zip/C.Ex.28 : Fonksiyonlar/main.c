// fonksiyonlar //
#include <stdio.h>
#include <math.h>
float CemberCapiHesaplama(float yaricap);
float CemberCevresiHesaplama(float yaricap);
float DaireAlanHesaplama(float yaricap);

int main(){
    float yaricap,cevre,cap,alan;
    printf("yarıçap: ");
    scanf("%f",&yaricap);
    
    cap=CemberCapiHesaplama(yaricap);
    cevre=CemberCevresiHesaplama(yaricap);
    alan=DaireAlanHesaplama(yaricap);
    
    printf("çember çapı:%.2f , çember çevresi:%.2f , daire alanı:%.2f ",cap,cevre,alan);
}

float CemberCapiHesaplama(float yaricap){
    return 2*yaricap;
}

float CemberCevresiHesaplama(float yaricap){
    return 2*M_PI*yaricap; // M_PI = Pİ = 3.14... 
                          // pi için math.h kütüpanesini dahil ettik
}

float DaireAlanHesaplama(float yaricap){
    return M_PI*yaricap*yaricap;
}

