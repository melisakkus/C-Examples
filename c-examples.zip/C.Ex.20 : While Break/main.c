/* while break komutu */
#include <stdio.h>
int main(){
    int sayi;
    printf("sayi: ");
    scanf("%d",&sayi);
    
    int i=1;
    while(i<=sayi){
        if(i==5){ 
            break; // koşul sağlandığında direk döngüden çıkartır
        }
    printf("%d ",i);
    i++;
    }
}