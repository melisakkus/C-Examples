/* dizilerde döngü ile eleman yazdırma */
#include <stdio.h>
int main(){
    int benimDizim[]={25,50,75,100};
    
    for (int indeks=0;indeks<4;indeks++){
        printf("%d ",benimDizim[indeks]);
    }
}