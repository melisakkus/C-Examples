//dosyadan okuma
#include <stdio.h>
#include <stdlib.h>

int main(){
    FILE *fptr; //dosyanın referansını tutan işaretçi
    char karakter; 
    
    fptr=fopen("yeniDosya.txt","r"); //dosyayı read modunda aç
    
    if(fptr==NULL){ //dosya açılamadıysa hata mesajı yaz ekrana
        printf("dosya okunamadı");
        exit(EXIT_FAILURE);
    }
    
    do{
        karakter=fgetc(fptr); //dosyadan 1 karakter oku
        putchar(karakter); //okuduğun karakteri ekrana yazdır
    }while(karakter != EOF); // end of file karakterine ulaşana kadar
    
    fclose(fptr);
    
    
}