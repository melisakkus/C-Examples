/* artık yıl bulma ; 
değer 4e bölünebiliyor ve 100e bölünebmiyorsa veya 400e bölünebiliyorsa ilgili yıl artık yıldır */

#include <stdio.h>
int main(){
    int yil;
    printf("yılı giriniz: ");
    scanf("%d",&yil);
    
    if(((yil%4 == 0) && (yil%100 != 0)) || (yil%400 == 0)){
        printf("%d artık yıldır",yil);
    }
    else{
        printf("%d artık yıl değildir",yil);
    }
}