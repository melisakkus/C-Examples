/* while kullanımı*/
#include <stdio.h>
int main(){
    int sayi,i;
    printf("sayi: ");
    scanf("%d",&sayi);
    
    i=1; // if 3 parçaya bölünmüş gibi
    while(i<=sayi){ // i<=sayi iken - bu koşul sağlandığı sürece içeri gir
        printf("%d ",i);
        i++;
    }
}