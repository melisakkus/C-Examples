// 4 işlemli hesap makinesi //

#include <stdio.h>
int main(){
    char islem;
    float sayi1,sayi2,sonuc=;
    
    printf("ilk sayıyı yapılmasını istediğiniz işlemi ve diğer sayıyı giriniz: ");
    scanf("%f %c %f",&sayi1,&islem,&sayi2);
    
    switch (islem){
        case '+':
            sonuc=sayi1+sayi2;
            printf("sonuc:%f",sonuc);
            break;
        case '-':
            sonuc=sayi1-sayi2;
            printf("sonuc:%f",sonuc);
            break;
        case '*':
            sonuc=sayi1*sayi2;
            printf("sonuc:%f",sonuc);
            break;
        case '/':
            sonuc=sayi1/sayi2;
            printf("sonuc:%f",sonuc);
            break;

    }
}