#include <stdio.h>
#include <stdlib.h>
#define metin_boyutu 500

int main(){
    char metin[metin_boyutu];
    FILE *dosyaişaretçisi;
    
    dosyaişaretçisi=fopen("yeniDosya.txt","w+");
    
    if(dosyaişaretçisi==NULL){
            printf("dosya açılamıyor");
            exit(EXIT_FAILURE);
    }
    
    printf("dosyay yazdırılacaklar: ");
    fgets(metin,metin_boyutu,stdin);
    fputs(metin,dosyaişaretçisi);
    fclose(dosyaişaretçisi);
}
