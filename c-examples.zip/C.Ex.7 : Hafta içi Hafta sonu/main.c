#include<stdio.h>
int main(){
    int gun;
    printf("haftanın kaçıncı günü: ");
    scanf("%d",&gun);
    
    switch(gun){
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            printf("haftaiçi");
            break;
        case 6:
        case 7:
            printf("haftasonu");
            break;
        default:
        printf("geçersiz");
    }
}