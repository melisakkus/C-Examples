// malloc örneği
#include <stdio.h>
#include <stdlib.h> // malloc gibi fonksiyonları kullanabilmek için 

int main(){
    int i,n, *isaretci, toplam=0;
    
    printf("toplanacak eleman sayısını giriniz: ");
    scanf("%d",&n);
    isaretci=(int*) malloc(n*sizeof(int));
    
    //istenilen alan ayrılamazsa
    if(isaretci == NULL){ 
        printf("Hata, bellek ayırma işlemi başarısız oldu.");
        exit(0);
    }
    
    printf("toplanacak eleman: ");
    for(i=0;i<n;i++){
        scanf("%d",isaretci+i);
        toplam = toplam + *(isaretci+i);
    }
    printf("toplam:%d",toplam);
    free(isaretci);
}

