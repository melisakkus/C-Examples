/* verilen sayıya kadar toplama */
#include <stdio.h>
int main(){
    int sayi,toplam=0;
    printf("sayıyı giriniz: ");
    scanf("%d",&sayi);
    
    for(int i=1;i<=sayi;i++){
        toplam += i ; // toplam = toplam + i; //
    }
    printf("%d ",toplam);
    
}