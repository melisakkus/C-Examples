/* diziler */
#include <stdio.h>
int main(){
    int denemeDizisi[]={25,50,75,100};
    denemeDizisi[0]=30;
    printf("%d",denemeDizisi[0]);
}