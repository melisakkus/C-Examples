// konum belirteci : extern
#include <stdio.h>

int x = 10; //global değişken
int y=30; //global değişken

int main(){
    extern int y;
    /* int y; /* extern tanımlanmazsa y 0 değerini alır ; aynı isimli değişkenlerde 
    lokal değer global değeri ezer. */
    printf("global x:%d\n",x);
    printf("extern y:%d",y);
}

