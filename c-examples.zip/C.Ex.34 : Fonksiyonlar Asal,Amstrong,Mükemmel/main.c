// sayı asal mı, amstrong mu, mükemmel mi?

#include<stdio.h>
#include<math.h>

int AsalMi(int sayi);
int ArmstrongMu(int sayi);
int MukemmelMi(int sayi);

int main(){
     int sayi;
    printf("sayıyı giriniz: ");
    scanf("%d",&sayi);
    
    if(AsalMi(sayi)){
        printf("\n sayı asaldır");
    }
    else{
        printf("\n asal değildir");
    }
    
    if(ArmstrongMu(sayi)){
        printf("\n %d sayi armstrongdur.",sayi);
    }
    else{
        printf("\n %d sayi armstrong değildir.",sayi);
    }
    
    if(MukemmelMi(sayi)){
        printf("\n %d sayısı mükemmeldir",sayi);
    }
    else{
        printf("\n %d sayısı mükemmel değildir",sayi);
    }
}

int AsalMi(int sayi){
    for(int i=2;i<sayi;i++){
        if(sayi % i == 0){
            return 0;
        }
    }
    return 1;
}

// abc sayısında (n basamak sayısı) a^n+b^n+c^n=abc ise sayı armstrongudr 
int ArmstrongMu(int sayi){
    int sonbasamak,basamaksayisi,toplam,orijinalsayi;
    toplam=0;
    orijinalsayi=sayi;

/* Birden büyük bir tam sayının kaç basamaklı olduğunu bulmak için 
sayının 10 tabanında logaritması alınır, sonucun ondalık kısmı atılır 
ve tam sayı kısmına 1 eklenir. */

    basamaksayisi=(int) log10(sayi) + 1;
    
    while(sayi>0){
        sonbasamak=sayi % 10; //son basamağı al
        toplam = toplam + round(pow(sonbasamak,basamaksayisi)); // son basamağın üstelini al ve toplama ekle
        sayi=sayi/10; //sayinin son basamağını yok et;
    }
    
    return (orijinalsayi == toplam);
    
}

int MukemmelMi(int sayi){
    int i,toplam;
    toplam = 0;
    
    for(i=1;i<sayi;i++){
        if(sayi%i==0){
            toplam=toplam+i;
        }
    }
    
    return (sayi==toplam);
    
}

