/* istenilen sayıya kadar ekranda yazdır */ 

#include <stdio.h>
int main (){
    int sayi;
    printf("sayıyı giriniz: ");
    scanf("%d",&sayi);
    
    for(int i=1;i<=sayi;i++){
        printf("%d ",i);
    }
    for(int i=1;sayi>=i;sayi--){
        printf("%d ",sayi);
    }

    for(int i=sayi;i>=1;i--){
        printf("%d ",i);
    }
}

/* döngü sayacını 1'den başlat (i=1)
    n değerine kadar git (i<=n)
    her seferinde döngü sayacını 1 arttır (i++)
    her seferinde i değerini yazdır ve alt satıra geç */