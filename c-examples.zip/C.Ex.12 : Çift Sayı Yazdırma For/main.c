/* verilen bir sayıya kadar tüm çift sayıları yazdırma*/
#include <stdio.h>
int main(){
    int sayi;
    printf("sayıyı giriniz: ");
    scanf("%d",&sayi);
    
    for(int i=2;i<=sayi;i=i+2){
        printf("%d ",i);
    }
    
    printf("\n");
    
    for(int i=1;i<=sayi;i++){
        if (i%2 == 0 ){
        printf("%d ",i);}
    }
}