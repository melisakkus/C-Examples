#include <stdio.h>
int main(){
    int sayi;
    printf("sayi: ");
    scanf("%d",&sayi);
    
    int i=1;
    while(i<=sayi){
        if(i==5){
            continue;
        }
    printf("%d",i);
    i++;
    }
}
/* continue ile 12 ve 13ü bu seferlik atlayıp 8'e döner
ama i++ olmadığı için döngüye girer, for da bu olmuyordu çünkü i++
ilk satırda döngü içerisindeydi */