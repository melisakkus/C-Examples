/* global - lokal değişkenler
Initialization (Başlatma): Initialization, bir değişkene başlangıç değeri atama işlemidir */

#include <stdio.h>

int g; /* global değişken deklarasyonu (beyanı)
main dışıda tanımlanan global değişken, bir atama yapılmadığı için ilklendirmesini 
derleyici otomatik olarak yapar. int 0, char '/0', float 0, double 0, pointer NULL - hiçbir 
yeri işaret etmez - olarak ilkkendirmeleri yapılır. */

int main(){
    int a,b; /*lokal değişkenlere programcı tarafından atama yapılmadıysa derleyici tarafındanda
               atama yani ilklendirme yapılmaz */
    a=10; //ilklendirmeleri yapılmakta
    b=20;
    g=a+b;
    
    printf("a:%d b:%d ve toplamları g:%d ",a,b,g);
    
}