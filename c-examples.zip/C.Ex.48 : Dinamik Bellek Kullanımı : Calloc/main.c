//calloc örneği
#include <stdio.h>
#include <stdlib.h>

int main(){
    int i,elemanSayisi,*isaretci,toplam=0;
    
    printf("toplanacak eleman sayısı: ");
    scanf("%d",&elemanSayisi);
    
    isaretci = (int*) calloc(elemanSayisi,sizeof(int));
    
    if(isaretci == NULL){
        printf("Hata, bellek tahsis edilemedi");
        exit(0);
    }
    
    for(i=0;i<elemanSayisi;i++){
    printf("toplanacak eleman: ");
        scanf("%d",isaretci +i);
        toplam += *(isaretci +i);
    }
    
    printf("Toplam:%d",toplam);
    
    free(isaretci);
}