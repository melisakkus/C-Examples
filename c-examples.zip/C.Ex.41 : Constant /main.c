// constant; sabitler - değişken olduğu halde aldığı değer değişmeyen evrensel gerçekler,
// pi'nin değeri, saate dakika gibi  
#include <stdio.h>
int main(){
    const int SaatteDakika = 60;
    const float PI = 3.14;
    printf("Bir saatte bulunan dakika sayısı:%d",SaatteDakika);
    printf("\nPi'nin değeri: %f",PI);
    // PI=PI+10; error: assignment of read-only variable ‘PI’
    // printf("\nPi'nin değeri: %f",PI); constant değişkenlere yeniden assignmentlar yapılamaz

}