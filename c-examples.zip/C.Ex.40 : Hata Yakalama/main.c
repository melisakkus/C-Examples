// hata yakalama
#include <stdio.h>
#include <stdlib.h>

int main( ){
    int bölünen;
    int bölen;
    int bölüm;
    
    printf("bölünen: ");
    scanf("%d",&bölünen);
    printf("\nbölen: ");
    scanf("%d",&bölen);
    
    
    if(bölen==0){
        printf("\nbölen 0 girilmiştir");
        exit(-1); // exit(EXIT_FAILURE)
    }
    
    bölüm=bölünen/bölen;
    printf("\nsonuç: %d",bölüm);
    exit(0); // exit(EXIT_SUCCESS)
}

