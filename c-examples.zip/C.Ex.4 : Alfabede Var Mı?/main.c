/* karakter alfabede bulunuyor mu? */

#include<stdio.h>
int main(){
    char karakter;
    printf("harfinizi giriniz: ");
    scanf("%c",&karakter);
    
    if(('a'<=karakter && karakter<='z') || ('A'<=karakter && karakter<='Z')){
        printf("%c karakteri alfabede bulunmaktadır",karakter);
    }
    else{
        printf("%c karakteri alfabede bulunmamaktadır",karakter);
    }
}