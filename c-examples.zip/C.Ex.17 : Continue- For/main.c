/* continue ; döngüde o adımı atla 
    break de olduğu gibi döngüyü kırmaz
    sadece o koşulu sağladığında devamını atlar*/

#include <stdio.h>
int main(){
    int sayi,i;
    printf("sayi: ");
    scanf("%d",&sayi);
    
    for(i=1;i<=sayi;i++){
       if(i==5) {
           continue;
       }
      printf("%d ",i);
    }
}
