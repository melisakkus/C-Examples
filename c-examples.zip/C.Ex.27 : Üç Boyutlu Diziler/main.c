#include <stdio.h>
int main(){
    int yeniDizi[2][3][4]={{{3,4,5,6,},{1,2,3,4},{8,7,6,5}}, // 3 satır 4 sütunluk ilk matris
                        {{4,5,6,2},{6,3,4,5},{8,7,0,2}}}; // 3 satır 4 sütunluk ikinci matris
                                    
    int i,j,k;
    for(i=0;i<2;i++){
        for(j=0;j<3;j++){
            for(k=0;k<4;k++){
                printf("%d ",yeniDizi[i][j][k]);
            }
            printf("\n");
        }
    printf("..............");
    }
}