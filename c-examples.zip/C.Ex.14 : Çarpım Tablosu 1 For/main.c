#include <stdio.h>
int main(){
    int sayi,carpim;
    printf("sayı: ");
    scanf("%d",&sayi);
    
    for(int i=1;i<=10;i++){
        carpim = sayi * i;
        printf("%d * %d = %d\n",i,sayi,carpim);
    }
}